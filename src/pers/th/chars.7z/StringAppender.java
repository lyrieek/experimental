package pers.th.chars;

public interface StringAppender {
	
	Words getValue();

}
