package pers.th.chars;

public interface StringHandle {

	Words set(Words item);
	
}
